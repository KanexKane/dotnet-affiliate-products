self.assetsManifest = {
  "version": "QTNtR3SH",
  "assets": [
    {
      "hash": "sha256-rw37nbbRalDYnFnIqoTR92+CdsVutSj8yOkuAK9kXHk=",
      "url": "AffiliateProduct.styles.css"
    },
    {
      "hash": "sha256-tpOzdp+DlmgHaJ0Fv1JBTHvJ1lXwbtnzi6kOdTfrvEo=",
      "url": "_framework/AffiliateProduct.yxfw3ytc60.wasm"
    },
    {
      "hash": "sha256-3YfAdOFRxy/yg6EiHZz1UHm2nRrqUQysiuULUI2wQzk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.jcafy9fy3t.wasm"
    },
    {
      "hash": "sha256-jB/Gf1i7eXuQqAzqY/ZONe+hrW3x94pYZlL+G0Cv7Co=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.0prlth0hc4.wasm"
    },
    {
      "hash": "sha256-ueQZunEOjL85VItJqkFsDf2Xw3IYauAEGJeY9TPeVHo=",
      "url": "_framework/Microsoft.AspNetCore.Components.hymu58d8tb.wasm"
    },
    {
      "hash": "sha256-V/8lrAHQfJYsJtV+bKRHL6fmMFhJhAOyoTNfGTbwTdQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.7sm4vp77d1.wasm"
    },
    {
      "hash": "sha256-M/V9DIZ9otM7/qEt+xn3wagkoRiLOf4JMPyDoo6WUM8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.n3roazub70.wasm"
    },
    {
      "hash": "sha256-XQykit2HYxnB0emmOc5bra6XuZq3KgCfazi8kFAErDs=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.jgtmx19396.wasm"
    },
    {
      "hash": "sha256-p4QWfZQ35PAVBSrYSf/h/37a1jHxifsVjl+fheJRxdU=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.j5a9d3dc0t.wasm"
    },
    {
      "hash": "sha256-wPj/fOeoE7JKOgIYh6OIvl/k3Iw6EPDmmXDjtnQ6rJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g0r86u4i0h.wasm"
    },
    {
      "hash": "sha256-BSVKL2EGTVINMfWn4lMAqkdPDNJpY0Ku7sM8CzOK9BY=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.xp29r1hwh3.wasm"
    },
    {
      "hash": "sha256-5E3YJsqbWNbv+OJiZ1kCoV5czf1fXeUBZBKig0eHQKs=",
      "url": "_framework/Microsoft.Extensions.Logging.km3zhtnk76.wasm"
    },
    {
      "hash": "sha256-2xzw4xsXcqL7SQ6R76v+GZrC7ZqwjD2SQaJrbh6IFlc=",
      "url": "_framework/Microsoft.Extensions.Options.xtnmlnlmnd.wasm"
    },
    {
      "hash": "sha256-+HoDX+e0bGwi8OjZvR5ZpN4OxMMBE8OX4f2wu++wdqE=",
      "url": "_framework/Microsoft.Extensions.Primitives.geznw6vy35.wasm"
    },
    {
      "hash": "sha256-hbzWuXrlepIqY/y+nQ2ZAFer2/njy1dc+Y4LUaAaL5E=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.p386u0jty9.wasm"
    },
    {
      "hash": "sha256-j93883TLWrUsylBnXBVb1aCW34uImOVFvkmgV7v8tx0=",
      "url": "_framework/Microsoft.JSInterop.bdr89uoxtd.wasm"
    },
    {
      "hash": "sha256-61G6RdWky6wSKMoiBGmJfoebCUZviZ5ID5YVq4HzR40=",
      "url": "_framework/System.Collections.Concurrent.fzjfrdn2ak.wasm"
    },
    {
      "hash": "sha256-HtRM8z6SWCHMrKQrNZIALzy2FMivErM+NlMU8wP0mA4=",
      "url": "_framework/System.Collections.Immutable.2sznr7iy82.wasm"
    },
    {
      "hash": "sha256-OKeiJJtliaKxbtNozMnLbTG8JY3GrcnhtdaJQYI9qRo=",
      "url": "_framework/System.Collections.cj575vce6f.wasm"
    },
    {
      "hash": "sha256-NQkKskUXENdTSf2C0+y41sjKi68CHmUqCgPPLNxKyGw=",
      "url": "_framework/System.ComponentModel.h9eo79o86x.wasm"
    },
    {
      "hash": "sha256-fG5C33jvnQc30BhFHHcR3muFlB4tfYRR2x1XYylDdrM=",
      "url": "_framework/System.Console.ckimbfyjuj.wasm"
    },
    {
      "hash": "sha256-13F6UCivKZPw1YCWlsitkOJtrLcBhCD2EXnx2WDWpKE=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.pse11zgi9v.wasm"
    },
    {
      "hash": "sha256-V5z9/XlJMVOFEDQ+R/mfLxmcykbKzh9+yhFeRdF4kdU=",
      "url": "_framework/System.IO.Pipelines.h68d94scrb.wasm"
    },
    {
      "hash": "sha256-d0Vk4oY2Rj7qfRMNNDTlnrokO8mEEE1MmNn51ICnnzA=",
      "url": "_framework/System.Linq.dfil2aohj8.wasm"
    },
    {
      "hash": "sha256-SrBVMo6y8K0FW1a07/LPx+E73mNBQDIPA1+IPvft0aI=",
      "url": "_framework/System.Memory.acxyzgdz32.wasm"
    },
    {
      "hash": "sha256-Z76MWouA0xOdZUMS1wK4Pc7OBRq+VuWERQ0jKveSpC4=",
      "url": "_framework/System.Net.Http.Json.9cqhqmryzt.wasm"
    },
    {
      "hash": "sha256-jvmxGOWCBsn2LcIacE+v9IxByj6zLNwTX/I51AbAW2s=",
      "url": "_framework/System.Net.Http.ayu7qlia5z.wasm"
    },
    {
      "hash": "sha256-RZU3+AurzUeBWgVjZalkA1jPlfRnehNr+R49gyYTuFI=",
      "url": "_framework/System.Net.Primitives.3uow9zd1kc.wasm"
    },
    {
      "hash": "sha256-lfYW1IpdAnwO+tB1TqptTdH7SrCZXcS0bwbLsAEOsQM=",
      "url": "_framework/System.Private.CoreLib.d6jidajsxh.wasm"
    },
    {
      "hash": "sha256-clTv5S18QHP9qji/PWwVyRgxjVJ0GIwgmTiS7QmL5Cw=",
      "url": "_framework/System.Private.Uri.uop6o79byp.wasm"
    },
    {
      "hash": "sha256-r+LQmgoVdHgFKWJvUNAR7HQZAtSw+xvBIQ6siSPsBNM=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.f4ln4hfftw.wasm"
    },
    {
      "hash": "sha256-1i0ZoYlLBt0DHqAr9uU7P34bCSH4Z9pRxBvVQDV2lgs=",
      "url": "_framework/System.Runtime.e6b17ey7s8.wasm"
    },
    {
      "hash": "sha256-gAQK1aO5MWD0GwIAc812qHpnec5wlHwgnyaZ9RGOUOg=",
      "url": "_framework/System.Text.Encodings.Web.4zpcd8unrt.wasm"
    },
    {
      "hash": "sha256-M7j8TUXGrHMH0vEQz6COEBFh7q5e3KbRHCdzquVcD4E=",
      "url": "_framework/System.Text.Json.34q8q6digi.wasm"
    },
    {
      "hash": "sha256-SKkTQL9D0Loskr+NX705/WITcRNb/8VQlQorMrz5S6M=",
      "url": "_framework/System.Text.RegularExpressions.0e9rlv7vxy.wasm"
    },
    {
      "hash": "sha256-mUEWnvrUT7jUp4kcQlNq/3rsQFo7hW7crmmOU0ioFp4=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-/pcrNUZIFxvVrfML8zazMdEZ+IB0TdSKqJ6mAPvV+w4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-HFADmT26AarHu4tMjFaTPxINmQjBJGtdPN+CKjtNMFE=",
      "url": "_framework/dotnet.native.8bti36lthm.js"
    },
    {
      "hash": "sha256-F3/BArijJUydqmwcdWeW3LYyYHBRSu2+pyy8GL1jTV0=",
      "url": "_framework/dotnet.native.tr0cyonrwt.wasm"
    },
    {
      "hash": "sha256-82FoDmY+LsehdN2u8aSGEutGEKXJHcYaSX/3zptbsCw=",
      "url": "_framework/dotnet.runtime.tsg4gsv2hg.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-6uD9zXF+lMXIa6OEHr6zb4P1KDZDjR0Nj/L7P4ysKxc=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-F+RRnuqLczejakbBGCDEDEBB91kuZa3YSJKGYTTCYKM=",
      "url": "data/product.json"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-Rpy75l4c3LSLs6lww/b2aBn7XPkPzIkAxKjsn4D6TZA=",
      "url": "fonts/Korbau.ttf"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-qlFjTpyuF4LxPDgQ4mZvxYN7q6SOXmuJOXOLljiTsPI=",
      "url": "images/bg.jpg"
    },
    {
      "hash": "sha256-1dCdfZeKiuCsHCVbXAj238n8zk2bUILztaFXfogFLLI=",
      "url": "images/bg2.png"
    },
    {
      "hash": "sha256-2USSQrBBbSs7YlBPYqZ9wZTUNsF7CgFlTxsFZ5adSVs=",
      "url": "images/bg3.jpg"
    },
    {
      "hash": "sha256-4UIbQjky2NjeTGIG8zMbRfyxyPeFB9Uc+ZgVJxzThO0=",
      "url": "images/bg4.jpg"
    },
    {
      "hash": "sha256-uCFFvXF7UbN2t8qYumuGH6Eb7z1Wf2SytC35l7OjPhs=",
      "url": "images/bg5.jpg"
    },
    {
      "hash": "sha256-NWm3pMMMN7yt0j0x4ZPsSxY9GRr9IMWWI2kANKuIoVA=",
      "url": "images/bragg-acv.jpg"
    },
    {
      "hash": "sha256-Qpj6PEe6/ffe4dIftP/8FVU87s5K5gdFMUqF1wYiIAY=",
      "url": "images/kanexkane-logo-179.png"
    },
    {
      "hash": "sha256-wpr12VqmRdfmfL+jO7yu5srlUYV/c3Sa+4JgBPeMu2Q=",
      "url": "images/kanexkane-logo-512.png"
    },
    {
      "hash": "sha256-93A8slCA6NPq13S30GhyoA8RNXexoxsjn+avIkIq3Es=",
      "url": "images/matcha-chatramue.jpg"
    },
    {
      "hash": "sha256-QT8ouM+utF+WLU5/oLepJwrEeg0ABw8onPg3b1S0lXk=",
      "url": "images/plantae-x-koithe.png"
    },
    {
      "hash": "sha256-YHtD5sowboWni6vbYM500CxPjtKQDyw08RPKzTedbPo=",
      "url": "images/tefal-purepop.png"
    },
    {
      "hash": "sha256-zcILJjJQrmoRUsdVKl1PqMGrDB0efe8FJTkW15S0nGo=",
      "url": "images/tnw-a37.png"
    },
    {
      "hash": "sha256-uDh2B8Bl+FCFPhPt7RmstXmIhh4SR3ehgO2hMPMR/cw=",
      "url": "images/usmile-cy1.jpg"
    },
    {
      "hash": "sha256-aFq2lK0w04wHl1dJYFWyOiU0STc1HREmTWP+A/pkmm8=",
      "url": "images/windbed.png"
    },
    {
      "hash": "sha256-meTb31T45EXpCkKDwKdbGuC9iC43P0VPhVVT8ywTvys=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-Q7H+R/LhJEYdc7tKE/u0pDX/4uXFllV0lS59Y0x2O5o=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-bh2MPERxpapO8puYMtsGsQnZEv7/fRMSkKRWyofQn+Y=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-P1zMFKuxc8hGAF1ol4FkFJKq0nytSNZ0Fxt27tJ5yLU=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-wbnN/Vu4StYrh8yYLoq8XYs4+j3ELQG+/W3c8TXRdV4=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-BdWcgt3+cDA103g/rMPhMinFBr0vrsDpwDfw9vdRFHM=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-wFTGfK2PR1T31rRzxwCZplpawXOGDKZRLu/p97yoShU=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-452+1O9+BQmxzjH+xjGwrOkwrJqtWvGZX6KhGN2vJr8=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-mz57hS1A5Wx7j/T8fCuVMbB4ViRy++SoOhqrOCDzflQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-EkoixIbNqUq5rWlahR/0Y5esnEvK3NJKYlHrnro0VIU=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-kWIS3E9n352l1JynbyoxSzgrXqwprVCgFIykQAJ+c2A=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
